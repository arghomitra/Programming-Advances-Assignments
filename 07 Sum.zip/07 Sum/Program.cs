﻿namespace _07_Sum
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Assignment assignment = new Assignment();
            List<int> list = assignment.Sum(int.Parse(Console.ReadLine()));
            Console.WriteLine(string.Join(" ",list));
            Console.WriteLine(list.Sum());
        }
    }
}